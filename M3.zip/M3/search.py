import heapq
import json
import re
import math
import time
from collections import defaultdict
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from inverted_index import InvertedIndex

class Search:
    def __init__(self):
        self.lookup_table = {}
        self.doc_id_to_url = {}
        self.doc_lengths = {}
        self.index_file = None
        self.ps = PorterStemmer()
        self.total_documents = 0
        self.avg_doc_length = 0


    def load_inverted_index_from_file(self, lookup_file_path, doc_mapping_file_path):
        print("Loading lookup table...")
        with open(lookup_file_path, 'r', encoding='utf-8') as f:
            self.lookup_table = json.load(f)
        
        print("Loading document mappings...")
        with open(doc_mapping_file_path, 'r', encoding='utf-8') as f:
            self.doc_id_to_url = json.load(f)
        
        with open("doc_lengths.json", 'r', encoding='utf-8') as f:
            self.doc_lengths = json.load(f)
        
        self.avg_doc_length = sum(int(length) for length in self.doc_lengths.values()) / len(self.doc_lengths)
        
        self.index_file = open("final_index.txt", 'r', encoding='utf-8')
        self.total_documents = len(self.doc_id_to_url)

    

    def get_postings(self, term, include_positions=False):
        if term not in self.lookup_table:
            return []
        
        offset = self.lookup_table[term]["offset"]
        length = self.lookup_table[term]["length"]
        
        self.index_file.seek(offset)
        line = self.index_file.read(length).strip()
        
        parts = line.split(' ', 1)
        if len(parts) != 2:
            return []
        
        term_read, postings_str = parts
        postings = []
        
        # format: docid:freq:hbc:tc:positions
        for posting_str in postings_str.split('|'):
            posting_parts = posting_str.split(':', 4)
            if len(posting_parts) == 5:
                docid = int(posting_parts[0])
                freq = int(posting_parts[1])
                hbc = int(posting_parts[2])
                tc = int(posting_parts[3])
                
                posting = {
                    "document_id": docid,
                    "frequency": freq,
                    "header_bold_count": hbc,
                    "title_count": tc
                }
                
                if include_positions:
                    positions_str = posting_parts[4]
                    positions = [int(p) for p in positions_str.split(',') if p]
                    posting["positions"] = positions
                
                postings.append(posting)
        
        return postings


    def bool_search(self, query):
        query_words = self._tokenize_query(query)
        if not query_words: 
            return []
        
        # add ngrams to query
        twogram = self._make_ngrams(query_words, 2)
        threegram = self._make_ngrams(query_words, 3)
        query_terms = query_words + twogram + threegram

        # OR search: collect all docs with any term
        all_doc_ids = set()
        postings_by_doc = defaultdict(lambda: {
            "frequency": 0,
            "header_bold_count": 0, 
            "title_count": 0
        })
        
        for word in query_terms:
            if word not in self.lookup_table:
                continue
            
            word_postings = self.get_postings(word)
            for posting in word_postings:
                doc_id = posting["document_id"]
                all_doc_ids.add(doc_id)
                postings_by_doc[doc_id]["frequency"] += posting["frequency"]
                postings_by_doc[doc_id]["header_bold_count"] += posting["header_bold_count"]
                postings_by_doc[doc_id]["title_count"] += posting["title_count"]
        
        if not all_doc_ids:
            return []
        
        combined_postings = []
        for doc_id in all_doc_ids:
            combined_postings.append({
                "document_id": doc_id,
                "frequency": postings_by_doc[doc_id]["frequency"],
                "header_bold_count": postings_by_doc[doc_id]["header_bold_count"],
                "title_count": postings_by_doc[doc_id]["title_count"]
            })
        
        results = self._cosine_search(combined_postings, 20, query_words)
        return results


    def _tokenize_query(self, query):
        InvertedIndex._check_punkt()
        query_tokens = word_tokenize(query.lower())
        query_stems = []
        
        for tok in query_tokens:
            if re.fullmatch(r"[a-z0-9]+", tok):
                stem = self.ps.stem(tok)
                query_stems.append(stem)
        return query_stems
    
    
    def _make_ngrams(self, stems, n):
        if len(stems) < n:
            return []

        ngrams = []
        for i in range(len(stems) - n + 1):
            ngrams.append("_".join(stems[i:i + n]))
    
        return ngrams


    def _calculate_proximity_score(self, query_words, document_id):
        # no proximity for single word
        if len(query_words) < 2:
            return 0
        
        term_positions = {}
        for word in query_words:
            if word not in self.lookup_table:
                continue
            
            word_postings = self.get_postings(word, include_positions=True)
            for posting in word_postings:
                if posting["document_id"] == document_id:
                    if "positions" in posting:
                        term_positions[word] = posting["positions"]
                    break
        
        if len(term_positions) < 2:
            return 0
        
        # find closest distance between any pair of terms
        min_distance = float('inf')
        terms = list(term_positions.keys())
        for i in range(len(terms)):
            for j in range(i + 1, len(terms)):
                term1_positions = term_positions[terms[i]]
                term2_positions = term_positions[terms[j]]
                
                for pos1 in term1_positions:
                    for pos2 in term2_positions:
                        distance = abs(pos1 - pos2)
                        min_distance = min(min_distance, distance)
        
        if min_distance == float('inf'):
            return 0
        
        # exponential decay with distance
        proximity_score = math.exp(-min_distance / 10)
        return proximity_score


    def _cosine_search(self, postings, k, query_words):
        start_time = time.time()
        max_time = 0.25
        
        title_boost = 3.0
        header_bold_boost = 1.5
        proximity_boost = 2.0
        
        # compute IDF for each term
        idf_scores = {}
        for word in query_words:
            if word in self.lookup_table:
                word_postings = self.get_postings(word)
                df = len(word_postings)
                idf = math.log(self.total_documents / df) if df > 0 else 0
                idf_scores[word] = idf
            else:
                idf_scores[word] = 0
        
        query_vector = defaultdict(int)
        for word in query_words:
            query_vector[word] += 1
        
        query_magnitude = math.sqrt(sum(count ** 2 for count in query_vector.values()))
        
        # prioritize likely good docs first
        postings.sort(
            key=lambda p: (
                p["title_count"] * 100 +
                p["header_bold_count"] * 10 +
                p["frequency"]
            ),
            reverse=True
        )
        
        top_k_heap = []
        
        for posting in postings:
            if time.time() - start_time > max_time:
                break
            
            document_id = posting["document_id"]
            doc_length = int(self.doc_lengths.get(str(document_id), self.avg_doc_length))
            
            # length normalization
            slope = 0.1
            length_norm = 1.0 - slope + slope * (doc_length / self.avg_doc_length)
            
            document_vector = {}
            document_mag_sq = 0
            
            for word in query_words:
                if word not in self.lookup_table:
                    continue
                
                word_postings = self.get_postings(word)
                
                matched_posting = None
                for p in word_postings:
                    if p["document_id"] == document_id:
                        matched_posting = p
                        break
                
                if matched_posting is not None:
                    tf_body = matched_posting["frequency"]
                    tf_title = matched_posting["title_count"]
                    tf_header_bold = matched_posting["header_bold_count"]
                    
                    effective_tf = (
                        tf_body + 
                        (tf_title * title_boost) + 
                        (tf_header_bold * header_bold_boost)
                    )
                    
                    log_tf = 1 + math.log(effective_tf) if effective_tf > 0 else 0
                    tf_idf = log_tf * idf_scores[word]
                    normalized_tf_idf = tf_idf / length_norm
                    
                    document_vector[word] = normalized_tf_idf
                    document_mag_sq += normalized_tf_idf * normalized_tf_idf
            
            base_score = 0
            for word in query_words:
                if word in document_vector:
                    base_score += document_vector[word]
            
            # add proximity bonus
            proximity_score = self._calculate_proximity_score(query_words, document_id)
            total_score = base_score + (proximity_score * proximity_boost)
            
            if len(top_k_heap) < k:
                heapq.heappush(top_k_heap, (total_score, document_id))
            elif total_score > top_k_heap[0][0]:
                heapq.heapreplace(top_k_heap, (total_score, document_id))
        
        sorted_results = sorted(top_k_heap, key=lambda x: x[0], reverse=True)
        
        final_results = []
        for score, document_id in sorted_results:
            final_results.append((self.doc_id_to_url[str(document_id)], document_id, score))
        
        return final_results
    
    
    def close(self):
        if self.index_file:
            self.index_file.close()
    
    
    def __del__(self):
        self.close()